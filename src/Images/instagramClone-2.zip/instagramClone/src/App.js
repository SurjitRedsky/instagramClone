import Login from "./pages/Login";
import './App.css'
import SignUp from "./pages/SignUp";


function App() {
  return (
    <div className="app">
      {/* <Login /> */}
      <SignUp/>
    </div>

  );
}

export default App;
