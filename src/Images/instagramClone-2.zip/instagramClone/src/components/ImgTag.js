import React from 'react'

const ImgTag = ({src,id,width}) => {
  return (
    <>
      <img src={src} id={id} width={width} className=''></img>
       </>
  )
}

export default ImgTag