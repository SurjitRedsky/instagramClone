import Login from "./Pages/Login";
import './App.css'


function App() {
  return (
    <div className="app">
   <Login/>
   
    </div>

  );
}

export default App;
